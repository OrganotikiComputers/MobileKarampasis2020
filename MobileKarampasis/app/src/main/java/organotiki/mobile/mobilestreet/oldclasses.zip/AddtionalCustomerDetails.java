package organotiki.mobile.mobilestreet;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;
import organotiki.mobile.mobilestreet.objects.Address;
import organotiki.mobile.mobilestreet.objects.Customer;
import organotiki.mobile.mobilestreet.objects.CustomerDetail;
import organotiki.mobile.mobilestreet.objects.GlobalVar;
import organotiki.mobile.mobilestreet.objects.InvoiceLineSimple;

/**
 * Created by Thanasis on 27/6/2016.
 */
public class AddtionalCustomerDetails extends AppCompatActivity implements Communicator {

    Realm realm;
    GlobalVar gVar;
    Customer customer;
    Address address;
    ArrayList<CustomerDetail> lines;
    ListView listView;
    VolleyRequests request;
    SwipeRefreshLayout mSwipeRefreshLayout;
    boolean customerIsUpdated = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_additional_customer_details);

            Toolbar toolbar = findViewById(R.id.addionalCustomerDetailsBar);
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);

            String cid = getIntent().getStringExtra("CustomerID");
            String aid = getIntent().getStringExtra("AddressID");

            realm = MyApplication.getRealm();
            gVar = realm.where(GlobalVar.class).findFirst();
            customer = realm.where(Customer.class).equalTo("ID", cid).findFirst();
            address = realm.where(Address.class).equalTo("ID", aid).findFirst();

            lines = new ArrayList<>();
            mSwipeRefreshLayout = findViewById(R.id.swipe_refresh_layout_additional_details);
            mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    realm.executeTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(Realm realm) {
                            try {
                                realm.delete(CustomerDetail.class);
                            } catch (Exception e) {
                                Log.e("asdfg", e.getMessage(), e);
                            }
                        }
                    });
                    request = new VolleyRequests();
                    request.getCustomerDetails(AddtionalCustomerDetails.this, "SenService/GetSenCustomerDetail", customer.getID());
                }
                });
            listView = findViewById(R.id.listView_addtitional_customer_details);

            realm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    try {
                        realm.delete(CustomerDetail.class);
                    } catch (Exception e) {
                        Log.e("asdfg", e.getMessage(), e);
                    }
                }
            });
            request = new VolleyRequests();
            request.getCustomerDetails(AddtionalCustomerDetails.this, "SenService/GetSenCustomerDetail", customer.getID());


        } catch (Exception e) {
            Log.e("asdfg", e.getMessage(), e);
        }
    }

//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.mywebview_menu, menu);
//        return true;
//    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        try {
            switch (item.getItemId()) {
//                case R.id.menuItem_send_email:
//                    try {
//                        doEmail();
//                    } catch (Exception e) {
//                        Log.e("asdfg", e.getMessage(), e);
//                    }
//                    break;
                case android.R.id.home:
                    finish();
            }
        } catch (Exception e) {
            Log.e("asdfg", e.getMessage(), e);
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        realm.close();
    }

    @Override
    public void respondCustomerSearch(Customer customer, Address address) {

    }

    @Override
    public void respondInvoiceType() {

    }

    @Override
    public void respondPaymentTerm() {

    }

    @Override
    public void respondCustomerCreate() {

    }

    @Override
    public void respondVolleyRequestFinished(Integer position, JSONObject jsonArray) {
        /*switch (position) {
            case 1:*/
                try {
                    RealmResults<CustomerDetail> rr = realm.where(CustomerDetail.class).findAll();
                    lines = new ArrayList<>();
                    for (CustomerDetail detail : rr) {
                        lines.add(detail);
                    }
                    MyListAdapter myListAdapter = new MyListAdapter();
                    listView.setAdapter(myListAdapter);
                    mSwipeRefreshLayout.setRefreshing(false);
                } catch (Exception e) {
                    Log.e("asdfg", e.getMessage(), e);
                }
               /* break;
        }*/
    }

    @Override
    public void respondDate(Integer position, int year, int month, int day) {

    }

    @Override
    public void respondCompanySite() {

    }

    @Override
    public void respondRecentPurchases(ArrayList<InvoiceLineSimple> sLines) {

    }

    private class MyListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (lines != null && lines.size() != 0) {
                return lines.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return lines.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, final ViewGroup parent) {
            try {
                final ViewHolder holder;
                if (convertView == null) {
                    holder = new ViewHolder();
                    LayoutInflater inflater = AddtionalCustomerDetails.this.getLayoutInflater();
                    convertView = inflater.inflate(R.layout.listview_additional_customer_details, null);
//                    convertView.setClickable(true);
//                    convertView.setFocusable(true);
                    final View finalConvertView = convertView;
                    holder.Header = convertView.findViewById(R.id.description);
                    holder.Value = convertView.findViewById(R.id.value);
                    convertView.setTag(holder);
                } else {
                    holder = (ViewHolder) convertView.getTag();
                }

                holder.ref = position;
//                holder.ID = lines.get(position).getID();
                holder.Header.setText(lines.get(position).getHeader());
                holder.Value.setText(lines.get(position).getValue());


            } catch (Exception e) {
                Log.e("asdfg", e.getMessage(), e);
            }

            return convertView;
        }

        private class ViewHolder {
            String ID;
            TextView Header;
            TextView Value;
            int ref;
        }
    }
}