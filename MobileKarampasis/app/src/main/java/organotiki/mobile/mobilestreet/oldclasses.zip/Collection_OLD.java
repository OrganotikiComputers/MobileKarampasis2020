/*
package organotiki.mobile.mobilestreet;

import android.app.FragmentManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;
import organotiki.mobile.mobilestreet.objects.Address;
import organotiki.mobile.mobilestreet.objects.Bank;
import organotiki.mobile.mobilestreet.objects.Company;
import organotiki.mobile.mobilestreet.objects.Customer;
import organotiki.mobile.mobilestreet.objects.FInvoiceLine;
import organotiki.mobile.mobilestreet.objects.GlobalVar;

*/
/**
 * Created by Thanasis on 15/7/2016.
 *//*

public class Collection_OLD extends AppCompatActivity implements Communicator {

    private Customer cus;
    private Spinner company;
    //    Button submit, close;
    private TextView txvCustomerCode, txvCustomerName, txvTotal, txvBalance1, txvBalance2;
    private EditText edtCash1, edtCash2;
    Realm realm;
    GlobalVar gVar;
    ArrayList<FInvoiceLine> lines;
    ListView mListView;
    ArrayList<String> banklist;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_collections);

            realm = Realm.getDefaultInstance();
            gVar = realm.where(GlobalVar.class).findFirst();

            Toolbar toolbar = (Toolbar) findViewById(R.id.collectionsBar);
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);

            ImageButton imbCus = (ImageButton) findViewById(R.id.imageButton_search_customer);
            if (imbCus != null) {
                imbCus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FragmentManager searchmanager = getFragmentManager();
                        SearchCustomerFragment searchfrag = new SearchCustomerFragment();
                        searchfrag.show(searchmanager, "Search Customer Fragment");

                    }
                });
            }

            RealmResults<Bank> banks = realm.where(Bank.class).findAll();
            Integer bankCount = banks.size();
            banklist = new ArrayList<>();
//            banklist.add("ΠΕΙΡΑΙΩΣ");
//            banklist.add("ΕΘΝΙΚΗ");
            for (int i = 0; i < bankCount; i++) {
                banklist.add(banks.get(i).getDescription());
            }

//            submit = (Button) findViewById(R.id.button_submit);
//            submit.setTransformationMethod(null);
//
//            close = (Button) findViewById(R.id.button_cancel);
//            close.setTransformationMethod(null);
//            close.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    finish();
//                }
//            });

            String codetxt;
            String nametxt;

            if (savedInstanceState != null) {
                cus = realm.where(Customer.class).equalTo("ID", savedInstanceState.getString("ID")).findFirst();
                codetxt = getResources().getString(R.string.cusCode) + ": " + cus.getCode();
                nametxt = getResources().getString(R.string.cusName) + ": " + cus.getName();
            } else {
                codetxt = getResources().getString(R.string.cusCode) + ": ";
                nametxt = getResources().getString(R.string.cusName) + ": ";
            }

            txvCustomerCode = (TextView) findViewById(R.id.textView_customer_code);
            txvCustomerCode.setText(codetxt);

            txvCustomerName = (TextView) findViewById(R.id.textView_customer_name);
            txvCustomerName.setText(nametxt);

            txvTotal = (TextView) findViewById(R.id.textView_total);
            txvTotal.setText(gVar.getMyFInvoice().getTotalText());

            txvBalance1 = (TextView) findViewById(R.id.textView_balance1);
            txvBalance2 = (TextView) findViewById(R.id.textView_balance2);

            edtCash1 = (EditText) findViewById(R.id.editText_cash1);
            edtCash1.setText(gVar.getMyFInvoice().getCash1Text());
            edtCash1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void afterTextChanged(Editable editable) {
                    try {

                        realm.executeTransaction(new Realm.Transaction() {
                            @Override
                            public void execute(Realm realm) {
                                gVar.getMyFInvoice().setCash1Text(String.valueOf(edtCash1.getText()));
                                gVar.getMyFInvoice().setTotal();
                            }
                        });
                        txvTotal.setText(gVar.getMyFInvoice().getTotalText());
                    } catch (NumberFormatException e) {
                        Log.e("asdfg", e.getMessage(), e);
                    }
                }
            });

            edtCash2 = (EditText) findViewById(R.id.editText_cash2);
            edtCash2.setText(gVar.getMyFInvoice().getCash2Text());
            edtCash2.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void afterTextChanged(Editable editable) {
                    try {

                        realm.executeTransaction(new Realm.Transaction() {
                            @Override
                            public void execute(Realm realm) {
                                gVar.getMyFInvoice().setCash2Text(String.valueOf(edtCash2.getText()));
                                gVar.getMyFInvoice().setTotal();
                            }
                        });
                        txvTotal.setText(gVar.getMyFInvoice().getTotalText());
                    } catch (NumberFormatException e) {
                        Log.e("asdfg", e.getMessage(), e);
                    }
                }
            });

            RealmResults<Company> companies = realm.where(Company.class).findAll();
            Integer companyCount = companies.size();
            ArrayList<String> list = new ArrayList<>();
            for (int i = 0; i < companyCount; i++) {
                list.add(companies.get(i).getDescription());
            }
            company = (Spinner) findViewById(R.id.spinner_company);
            // Create an ArrayAdapter using the string array and a default spinner layout
            final ArrayAdapter<String> mAdapter = new ArrayAdapter<>(this, R.layout.spinner_collections_item, list);
            // Specify the layout to use when the list of choices appears
//            mAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // Apply the mAdapter to the spinner
            company.setAdapter(mAdapter);
            company.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//                    txvBalance1.setText(String.valueOf(realm.where(Company.class).equalTo("Description", String.valueOf(adapterView.getItemAtPosition(i))).findFirst().getDebit1()));
//                    txvBalance2.setText(String.valueOf(realm.where(Company.class).equalTo("Description", String.valueOf(adapterView.getItemAtPosition(i))).findFirst().getDebit2()));
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });
            company.setSelection(0);

            RelativeLayout layoutCus = (RelativeLayout) findViewById(R.id.relativeLayout_cus); // id fetch from xml
            if (layoutCus != null) {
                layoutCus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FragmentManager searchmanager = getFragmentManager();
                        SearchCustomerFragment searchfrag = new SearchCustomerFragment();
                        searchfrag.show(searchmanager, "Search Customer Fragment");
                    }
                });
            }

            lines = new ArrayList<>();
            */
/*final FInvoiceLine line = new FInvoiceLine(UUID.randomUUID().toString(), gVar.getMyEInvoice());
            realm.executeTransaction(new Realm.FTransaction() {
                @Override
                public void execute(Realm realm) {
                    FInvoiceLine l = realm.copyToRealmOrUpdate(line);
                    lines.add(l);
                }
            });*//*

            mListView = (ListView) findViewById(R.id.listView_checks);
            mListView.setAdapter(new MyListAdapter());


        } catch (Exception e) {
            Log.e("asdfg", e.getMessage(), e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        realm.back();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        try {
            getMenuInflater().inflate(R.menu.collections_menu, menu);
        } catch (Exception e) {
            Log.e("asdfg", e.getMessage(), e);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        try {
            switch (item.getItemId()) {
                case R.id.menuItem_add_check:
                    try {
                        */
/*final FInvoiceLine line = new FInvoiceLine(UUID.randomUUID().toString(), gVar.getMyEInvoice());
                        realm.executeTransaction(new Realm.FTransaction() {
                            @Override
                            public void execute(Realm realm) {
                                FInvoiceLine l = realm.copyToRealmOrUpdate(line);
                                lines.add(l);
                            }
                        });
                        mListView = (ListView) findViewById(R.id.listView_checks);
                        mListView.setAdapter(new MyListAdapter());*//*

//                    saveItemList();
                    } catch (Exception e) {
                        Log.e("asdfg", e.getMessage(), e);
                    }

                    return super.onOptionsItemSelected(item);

                case R.id.menuItem_submit:
//                    FragmentManager createmanager = getFragmentManager();
//                    CreateCustomerFragment createfrag = new CreateCustomerFragment();
//                    createfrag.show(createmanager, "Create Customer Fragment");

                    return super.onOptionsItemSelected(item);
//                case android.R.id.home:
//                    doExit();
//                    return true;

            }
        } catch (Exception e) {
            Log.e("asdfg", e.getMessage(), e);
            return false;
        }
        return false;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("ID", cus == null ? "" : cus.getID());
    }

    @Override
    public void respondCustomerSearch(Customer customer, Address address) {
        try {
            cus = customer;
            String codetxt = getResources().getString(R.string.cusCode) + ": " + cus.getCode();
            txvCustomerCode.setText(codetxt);

            String nametxt = getResources().getString(R.string.cusName) + ": " + cus.getName();
            txvCustomerName.setText(nametxt);
        } catch (Resources.NotFoundException e) {
            Log.e("asdfg", e.getMessage(), e);
        }
    }

    @Override
    public void respondInvoiceType() {

    }

    @Override
    public void respondPaymentTerm() {

    }

    @Override
    public void respondCustomerCreate() {

    }

    @Override
    public void respondVolleyRequestFinished(Integer position, JSONObject jsonArray) {

    }

    @Override
    public void respondDate(final Integer position, final int year, final int month, final int day) {
        try {
            realm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    lines.get(position).setExDate(day + "/" + month + "/" + year);
                }
            });
            mListView = (ListView) findViewById(R.id.listView_checks);
            mListView.setAdapter(new MyListAdapter());
//            ((MyListAdapter.ViewHolder)mListView.getItemAtPosition(position)).ExpirationDate.setText(lines.get(position).getExDate());
        } catch (Exception e) {
            Log.e("asdfg", e.getMessage(), e);
        }
    }

    private class MyListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (lines != null && lines.size() != 0) {
                return lines.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return lines.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, final ViewGroup parent) {
            try {
                final ViewHolder holder;
                if (convertView == null) {
                    holder = new ViewHolder();
                    LayoutInflater inflater = Collection_OLD.this.getLayoutInflater();
                    convertView = inflater.inflate(R.layout.listview_collections, null);
                    holder.Bank = (Spinner) convertView.findViewById(R.id.spinner_bank);
                    ArrayAdapter<String> mAdapter = new ArrayAdapter<>(Collection_OLD.this, R.layout.spinner_collections_item, banklist);
                    // Specify the layout to use when the list of choices appears
//                      mAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    // Apply the mAdapter to the spinner
                    holder.Bank.setAdapter(mAdapter);
                    holder.Bank.setSelection(0);
                    holder.Bank.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(final AdapterView<?> adapterView, View view, final int i, long l) {
                            try {
                                realm.executeTransaction(new Realm.Transaction() {
                                    @Override
                                    public void execute(Realm realm) {
                                        try {
                                            lines.get(holder.ref).setMyBank(realm.where(Bank.class).equalTo("Description", String.valueOf(adapterView.getItemAtPosition(i))).findFirst());
                                        } catch (Exception e) {
                                            Log.e("asdfg", e.getMessage(), e);
                                        }
                                    }
                                });
                            } catch (Exception e) {
                                Log.e("asdfg", e.getMessage(), e);
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }
                    });

                    holder.ExpirationDate = (EditText) convertView.findViewById(R.id.editText_expiration_date);
                    holder.ExpirationDate.setKeyListener(null);
                    holder.ExpirationDate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            FragmentManager manager = getFragmentManager();
                            DatePickerFragment fragment = new DatePickerFragment();
                            fragment.setPosition(holder.ref);
                            fragment.show(manager, "datePicker");
                        }
                    });
                    holder.Number = (EditText) convertView.findViewById(R.id.editText_number);
                    holder.Number.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        }

                        @Override
                        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        }

                        @Override
                        public void afterTextChanged(Editable editable) {
                            try {
                                realm.executeTransaction(new Realm.Transaction() {
                                    @Override
                                    public void execute(Realm realm) {
                                        lines.get(holder.ref).setNumber(String.valueOf(holder.Number.getText()));
                                    }
                                });
                            } catch (Exception e) {
                                Log.e("asdfg", e.getMessage(), e);
                            }
                        }
                    });
                    holder.Value = (EditText) convertView.findViewById(R.id.editText_value);
                    holder.Value.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        }

                        @Override
                        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                        }

                        @Override
                        public void afterTextChanged(Editable editable) {
                            try {
                                realm.executeTransaction(new Realm.Transaction() {
                                    @Override
                                    public void execute(Realm realm) {
                                        lines.get(holder.ref).setValueText(String.valueOf(holder.Value.getText()));
                                        gVar.getMyFInvoice().setTotal();
//                                        gVar.getMyFInvoice().setTotal();Log.d("asdfg", "subtotal: "+String.valueOf(realm.where(FInvoiceLine.class).equalTo("myEInvoice.ID", gVar.getMyEInvoice().getID()).findFirst().getValue()));
                                    }
                                });
                                txvTotal.setText(gVar.getMyFInvoice().getTotalText());
                            } catch (Exception e) {
                                Log.e("asdfg", e.getMessage(), e);
                            }
                        }
                    });
                    holder.Delete = (ImageButton) convertView.findViewById(R.id.imageButton_delete);
                    holder.Delete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            realm.executeTransaction(new Realm.Transaction() {
                                @Override
                                public void execute(Realm realm) {
                                    lines.get(holder.ref).deleteFromRealm();
                                    lines.remove(holder.ref);
                                }
                            });
                            mListView = (ListView) findViewById(R.id.listView_checks);
                            mListView.setAdapter(new MyListAdapter());
                        }
                    });
                    convertView.setTag(holder);
                } else {
                    holder = (ViewHolder) convertView.getTag();
                }

                holder.ref = position;

                holder.ExpirationDate.setText(lines.get(holder.ref).getExDate());
                holder.Number.setText(lines.get(holder.ref).getNumber());
                holder.Value.setText(lines.get(holder.ref).getValueText());


            } catch (Exception e) {
                Log.e("asdfg", e.getMessage(), e);
            }

            return convertView;
        }

        class ViewHolder {
            String ID;
            Spinner Bank;
            EditText ExpirationDate;
            EditText Number;
            EditText Value;
            int ref;
            ImageButton Delete;
        }
    }
}*/
